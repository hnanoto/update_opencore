#!/usr/bin/env python3

import os
import sys
import plistlib
import requests
import zipfile
import shutil
import time
import subprocess
import tempfile

# Cores para feedback visual
RED = "\033[0;31m"
GREEN = "\033[0;32m"
YELLOW = "\033[0;33m"
NC = "\033[0;m"  # Sem cor

# Caminho absoluto para o diretório do script
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))

# Arquivo de log
LOGFILE = f"update_opencore_{time.strftime('%Y%m%d%H%M%S')}.log"

# Variavel Global para armazenar a versao do opencore
OC_VERSION = ""

def log_message(message):
    """Writes a message to the log file and prints it to the console."""
    with open(LOGFILE, "a") as log:
        log.write(message + "\n")
    print(message)

def check_environment():
    """Verifica o ambiente e permissões."""
    log_message(f"{YELLOW}Verificando ambiente...{NC}")
    if os.name != "posix" or "darwin" not in sys.platform:
        log_message(f"{RED}Erro: Este script deve ser executado no macOS.{NC}")
        exit(1)
    if os.geteuid() != 0:
        log_message(
            f"{YELLOW}Este script requer permissões de administrador. Solicitando sudo...{NC}"
        )
        # Re-run the script with sudo
        subprocess.run(["sudo", sys.executable] + sys.argv, check=True)
        exit()
    log_message(f"{GREEN}Ambiente verificado com sucesso.{NC}")

def check_dependencies():
    """Verifica dependências."""
    log_message(f"{YELLOW}Verificando dependências...{NC}")
    dependencies = {
        "curl": "curl",
        "unzip": "unzip",
        "PlistBuddy": "/usr/libexec/PlistBuddy",
        "python3": sys.executable,
    }
    for dep, path in dependencies.items():
        if shutil.which(path) is None:
            log_message(f"{RED}Erro: Dependência '{dep}' não encontrada.{NC}")
            if dep == "python3":
                log_message(
                    f"{YELLOW}O Python 3 é necessário para o script. Instale-o através do Homebrew com 'brew install python3'.{NC}"
                )
            exit(1)

    log_message(f"{GREEN}Todas as dependências estão disponíveis.{NC}")

# Função modificada para verificar ocvalidate após o download e dar permissão de execução
def check_ocvalidate(source_opencore_dir):
    """Verifica se o ocvalidate existe no diretório do OpenCore baixado."""
    ocvalidate_path = os.path.join(source_opencore_dir, "Utilities", "ocvalidate", "ocvalidate")
    if os.path.isfile(ocvalidate_path):
        log_message(f"{GREEN}ocvalidate encontrado em: {ocvalidate_path}{NC}")
        # Dar permissão de execução ao ocvalidate
        os.chmod(ocvalidate_path, 0o755)  # Adiciona permissão de execução # Modificação
        return ocvalidate_path
    else:
        log_message(f"{YELLOW}Aviso: ocvalidate não encontrado em {source_opencore_dir}. A validação do config.plist será pulada.{NC}")
        return None

def download_oc(release_type="RELEASE"):
    """Downloads and extracts the latest OpenCore version."""
    log_message(f"{YELLOW}Baixando OpenCore versão {release_type}...{NC}")
    try:
        response = requests.get(
            "https://api.github.com/repos/acidanthera/OpenCorePkg/releases/latest",
            timeout=10,
        )
        response.raise_for_status()
        oc_data = response.json()
        global OC_VERSION
        OC_VERSION = oc_data["tag_name"]
        oc_url = ""
        for asset in oc_data["assets"]:
            if f"{release_type}.zip" in asset["name"]:
                oc_url = asset["browser_download_url"]
                break

        if not oc_url:
            raise ValueError(
                f"Não foi possível obter o link da versão {release_type} do OpenCore."
            )

        log_message(f"Link de download do OpenCore versão {release_type} encontrado: {oc_url}")
        
        # Usar um diretório temporário com tempfile
        temp_dir = tempfile.mkdtemp() # Modificação
        temp_file = os.path.join(temp_dir, "OpenCore.zip")

        response = requests.get(oc_url, stream=True, timeout=10)
        response.raise_for_status()

        with open(temp_file, "wb") as f:
            for chunk in response.iter_content(chunk_size=8192):
                f.write(chunk)

        # Check if the ZIP file is valid before extracting
        with zipfile.ZipFile(temp_file, "r") as zip_ref:
            if zip_ref.testzip() is not None:
                raise ValueError("O arquivo ZIP do OpenCore está corrompido ou inválido.")
            zip_ref.extractall(os.path.join(temp_dir, "OpenCore"))
        
        # Verificando o conteúdo do diretório temporário
        log_message(f"{YELLOW}Conteúdo do diretório temporário: {os.listdir(os.path.join(temp_dir, 'OpenCore'))}{NC}") # Modificação
        log_message(f"{YELLOW}Conteúdo do diretório X64: {os.listdir(os.path.join(temp_dir, 'OpenCore', 'X64'))}{NC}") # Modificação

        log_message(f"{GREEN}OpenCore versão {release_type} baixado e extraído com sucesso em diretório temporário.{NC}")
        log_message(f"Diretório temporário do OpenCore: {os.path.join(temp_dir, 'OpenCore')}") # Modificação
        return temp_dir, os.path.join(temp_dir, "OpenCore") # Modificação

    except requests.exceptions.RequestException as e:
        log_message(f"{RED}Erro ao baixar OpenCore: {e}{NC}")
        exit(1)
    except ValueError as e:
        log_message(f"{RED}Erro: {e}{NC}")
        exit(1)
    except (zipfile.BadZipFile, OSError) as e:
        log_message(f"{RED}Erro ao extrair OpenCore.zip: {e}{NC}")
        exit(1)

def list_all_efi():
    """Lists all EFI partitions and prompts the user to select one."""
    log_message(f"{YELLOW}Localizando todas as partições EFI no sistema...{NC}")
    try:
        result = subprocess.run(["diskutil", "list"], capture_output=True, text=True, check=True)
        efi_partitions = [
            line.split()[-1]
            for line in result.stdout.splitlines()
            if "EFI" in line and "disk" in line
        ]

        if not efi_partitions:
            raise ValueError("Nenhuma partição EFI encontrada.")

        log_message("Partições EFI detectadas:")
        for i, efi in enumerate(efi_partitions):
            log_message(f"{i + 1}. {efi}")

        while True:
            try:
                choice = int(
                    input("Selecione o número da partição EFI que deseja usar: ")
                )
                if 1 <= choice <= len(efi_partitions):
                    efi_part = efi_partitions[choice - 1]
                    break
                else:
                    log_message(f"{RED}Seleção inválida. Tente novamente.{NC}")
            except ValueError:
                log_message(f"{RED}Entrada inválida. Por favor, insira um número.{NC}")

        result = subprocess.run(
            ["diskutil", "info", efi_part], capture_output=True, text=True, check=True
        )
        mount_point = None
        for line in result.stdout.splitlines():
            if "Mount Point:" in line:
                mount_point = line.split(":", 1)[1].strip()
                break

        if not mount_point:
            log_message(
                f"{RED}Erro: A partição EFI selecionada não está montada.{NC}\n"
                f"{YELLOW}Monte a EFI manualmente e execute o script novamente.{NC}"
            )
            exit(1)

        log_message(f"Partição EFI selecionada: {efi_part}")
        log_message(f"Ponto de montagem: {mount_point}")
        return mount_point

    except subprocess.CalledProcessError as e:
        log_message(f"{RED}Erro ao executar diskutil: {e}{NC}")
        exit(1)
    except ValueError as e:
        log_message(f"{RED}Erro: {e}{NC}")
        exit(1)

def backup_efi(efi_dir):
    """Cria backup da EFI."""
   # Modificação: Volta a fazer backup na própria partição EFI
    backup_dir = os.path.join(
        efi_dir, f"EFI-Backup-{time.strftime('%Y%m%d%H%M%S')}"
    )
    log_message(f"{YELLOW}Criando backup em {backup_dir}...{NC}")

    # Cria o diretório de backup antes
    os.makedirs(backup_dir, exist_ok=True)

    try:
        source_efi = os.path.join(efi_dir, "EFI")
        for item in os.listdir(source_efi):
            s = os.path.join(source_efi, item)
            d = os.path.join(backup_dir, item)
            if os.path.isdir(s):
                shutil.copytree(s, d, copy_function=shutil.copy) # Usar shutil.copy para evitar cópia de atributos estendidos
            else:
                shutil.copy2(s, d) # shutil.copy2 ainda é necessário para preservar metadados de arquivos comuns

        log_message(f"{GREEN}Backup criado com sucesso.{NC}")
    except Exception as e:
        log_message(f"{RED}Erro ao criar o backup: {e}{NC}")
        exit(1)

def update_efi(efi_dir, source_opencore_dir, release_type="RELEASE"):
    """Atualiza os arquivos EFI."""
    efi_path = os.path.join(efi_dir, "EFI")
    if not os.path.isdir(efi_path):
        log_message(f"{RED}Erro: Diretório EFI não encontrado em {efi_dir}.{NC}")
        exit(1)

    log_message(f"{YELLOW}Atualizando arquivos EFI em {efi_path} com OpenCore {OC_VERSION}...{NC}")
    try:
        # Correção: O caminho para a pasta EFI agora está correto
        source_efi = os.path.join(source_opencore_dir, "X64", "EFI") # Modificação

        for item in os.listdir(source_efi):
            s = os.path.join(source_efi, item)
            d = os.path.join(efi_path, item)

            if item == "OC":
                # Não sobrescrever a pasta OC existente
                log_message(f"{YELLOW}Pasta OC encontrada. Preservando a pasta OC existente e seu conteúdo...{NC}")

                # Copiar apenas o conteúdo da pasta OC da nova versão do OpenCore
                source_oc = s  # A pasta OC já é 's'
                dest_oc = os.path.join(d, "OC")

                for oc_item in os.listdir(source_oc):
                    source_item_path = os.path.join(source_oc, oc_item)
                    dest_item_path = os.path.join(dest_oc, oc_item)

                    if oc_item in ["ACPI", "config.plist"]:
                        # Não sobrescrever a pasta ACPI existente e nem o config.plist
                        log_message(f"{YELLOW}Pulando {oc_item} para preservar configurações existentes.{NC}")
                        continue
                    elif os.path.isdir(source_item_path):
                        if os.path.exists(dest_item_path):
                            shutil.rmtree(dest_item_path)  # Remove existing directory before copying
                        shutil.copytree(source_item_path, dest_item_path)
                        log_message(f"{YELLOW}Pasta {oc_item} atualizada.{NC}")
                    else:
                        shutil.copy2(source_item_path, dest_item_path)
                        log_message(f"{YELLOW}Arquivo {oc_item} atualizado.{NC}")

            elif os.path.isdir(s):
                # Copiar outras pastas (BOOT, Drivers, etc.)
                if os.path.exists(d):
                    shutil.rmtree(d)
                shutil.copytree(s, d)
                log_message(f"{YELLOW}Pasta {item} atualizada.{NC}")
            else:
                # Copiar arquivos soltos
                shutil.copy2(s, d)
                log_message(f"{YELLOW}Arquivo {item} atualizado.{NC}")

        log_message(f"{GREEN}Arquivos EFI atualizados com sucesso.{NC}")
    except Exception as e:
        log_message(f"{RED}Erro ao copiar arquivos EFI: {e}{NC}")
        exit(1)

def check_efi_permissions(efi_dir):
    """Verifica se o script tem permissão de leitura no diretório EFI e seus subdiretórios."""
    efi_path = os.path.join(efi_dir, "EFI")
    log_message(f"{YELLOW}Verificando permissões de leitura em {efi_path}...{NC}")

    if not os.access(efi_path, os.R_OK):
        log_message(f"{RED}Erro: Sem permissão de leitura para o diretório EFI: {efi_path}{NC}")
        exit(1)

    for root, dirs, files in os.walk(efi_path):
        for dir_name in dirs:
            dir_path = os.path.join(root, dir_name)
            if not os.access(dir_path, os.R_OK):
                log_message(f"{RED}Erro: Sem permissão de leitura para o diretório: {dir_path}{NC}")
                exit(1)

    log_message(f"{GREEN}Permissões de leitura verificadas com sucesso.{NC}")

def find_config_plist(efi_dir):
    """
    Procura o arquivo config.plist na pasta EFI.
    Retorna o caminho completo para o config.plist se encontrado, senão retorna None.
    """
    config_plist_path = os.path.join(efi_dir, "EFI", "OC", "config.plist")
    if os.path.isfile(config_plist_path):
        return config_plist_path

    # Se não encontrou no local padrão, busca em toda a pasta EFI
    log_message(f"{YELLOW}config.plist não encontrado em {config_plist_path}. Procurando em outros locais...{NC}")
    for root, dirs, files in os.walk(os.path.join(efi_dir, "EFI")):
        log_message(f"{YELLOW}Procurando em: {root}...{NC}")
        for file in files:
            log_message(f"{YELLOW}  Arquivo encontrado: {file}...{NC}")
            if file == "config.plist":
                config_plist_path = os.path.join(root, file)
                log_message(f"{YELLOW}config.plist encontrado em: {config_plist_path}{NC}")
                return config_plist_path

    log_message(f"{RED}Erro: config.plist não encontrado na pasta EFI.{NC}")
    return None

def get_efi_oc_version(config_plist_path):
    """
    Obtém a versão do OpenCore a partir do config.plist.
    Retorna a versão como string ou None se não conseguir determinar.
    """
    try:
        with open(config_plist_path, "rb") as f:
            config_plist = plistlib.load(f)

        # A versão do OpenCore está em Misc -> Tools -> OpenCore
        tools = config_plist.get("Misc", {}).get("Tools", [])
        for tool in tools:
            if tool.get("Path") == "OpenCore.efi" and "Comment" in tool:
                version_str = tool["Comment"]
                # Extrair a versão da string (ex: "OpenCore version 0.9.7")
                if "version" in version_str:
                    version = version_str.split("version")[1].strip()
                    log_message(f"{YELLOW}Versão do OpenCore encontrada no config.plist: {version}{NC}")
                    return version

        log_message(f"{YELLOW}Não foi possível determinar a versão do OpenCore a partir do config.plist.{NC}")
        return None
    except Exception as e:
        log_message(f"{RED}Erro ao ler o config.plist para obter a versão do OpenCore: {e}{NC}")
        return None

def get_latest_oc_version():
    """
    Obtém a versão mais recente do OpenCore da API do GitHub.
    Retorna a versão como string ou None se não conseguir determinar.
    """
    try:
        response = requests.get(
            "https://api.github.com/repos/acidanthera/OpenCorePkg/releases/latest",
            timeout=10,
        )
        response.raise_for_status()
        oc_data = response.json()
        version = oc_data["tag_name"]
        log_message(f"{YELLOW}Versão mais recente do OpenCore no GitHub: {version}{NC}")
        return version
    except Exception as e:
        log_message(f"{RED}Erro ao obter a versão mais recente do OpenCore: {e}{NC}")
        return None

def compare_oc_versions(current_version, latest_version):
    """
    Compara as versões do OpenCore e retorna True se a versão atual é mais antiga.
    Retorna False se as versões são iguais ou se a versão atual é mais recente.
    """
    if current_version is None or latest_version is None:
        return False

    try:
        # Converte as versões para uma lista de inteiros para comparação
        current_parts = [int(part) for part in current_version.split(".")]
        latest_parts = [int(part) for part in latest_version.split(".")]

        if current_parts < latest_parts:
            log_message(f"{YELLOW}Versão instalada do OpenCore ({current_version}) é mais antiga que a versão mais recente ({latest_version}).{NC}")
            return True
        elif current_parts > latest_parts:
            log_message(f"{GREEN}Versão instalada do OpenCore ({current_version}) é mais recente que a versão mais recente ({latest_version}). NÃO SERÁ ATUALIZADO.{NC}")
            return False
        else:
            log_message(f"{GREEN}Versão instalada do OpenCore ({current_version}) é a mesma que a versão mais recente ({latest_version}). NÃO SERÁ ATUALIZADO.{NC}")
            return False

    except ValueError:
        log_message(f"{RED}Erro ao comparar as versões do OpenCore.{NC}")
        return False

def get_enabled_drivers(config_plist_path):
    """
    Obtém a lista de drivers habilitados no config.plist.
    Retorna uma lista de nomes de drivers.
    """
    enabled_drivers = []

    if not os.path.isfile(config_plist_path):
        log_message(f"{RED}Erro: Arquivo config.plist não encontrado em {config_plist_path}.{NC}")
        exit(1)

    try:
        with open(config_plist_path, "rb") as f:
            config_plist = plistlib.load(f)

        uefi_drivers = config_plist.get("UEFI", {}).get("Drivers", [])

        for driver in uefi_drivers:
            if isinstance(driver, dict):
                if driver.get("Enabled", False):
                    enabled_drivers.append(driver.get("Path", ""))
            elif isinstance(driver, str):
                # Se for uma string, é o caminho direto do driver
                enabled_drivers.append(driver)

    except Exception as e:
        log_message(f"{RED}Erro ao processar config.plist: {e}{NC}")
        exit(1)

    return enabled_drivers

def update_drivers(efi_dir, config_plist_path, source_opencore_dir):
    """Atualiza os drivers na pasta EFI/OC/Drivers."""
    efi_drivers_dir = os.path.join(efi_dir, "EFI", "OC", "Drivers")
    new_drivers_dir = os.path.join(source_opencore_dir, "X64/EFI/OC/Drivers")

    if not os.path.isdir(efi_drivers_dir):
        log_message(f"{RED}Erro: Pasta de drivers EFI não encontrada em {efi_drivers_dir}.{NC}")
        exit(1)

    enabled_drivers = get_enabled_drivers(config_plist_path)

    log_message(f"{YELLOW}Atualizando drivers em {efi_drivers_dir}...{NC}")

    for driver_file in os.listdir(new_drivers_dir):
        if driver_file.endswith(".efi"):
            driver_name = driver_file
            new_driver_path = os.path.join(new_drivers_dir, driver_file)
            efi_driver_path = os.path.join(efi_drivers_dir, driver_file)

            if driver_name in enabled_drivers:
                if os.path.isfile(efi_driver_path):
                    # Compara as datas de modificação
                    if os.path.getmtime(new_driver_path) > os.path.getmtime(efi_driver_path):
                        log_message(f"{YELLOW}Atualizando {driver_name} (nova versão encontrada)...{NC}")
                        try:
                            shutil.copy2(new_driver_path, efi_driver_path)
                        except Exception as e:
                            log_message(f"{RED}Erro ao atualizar {driver_name}: {e}{NC}")
                            exit(1)
                    else:
                        log_message(f"{YELLOW}Driver {driver_name} já está atualizado. Pulando.{NC}")
                else:
                    log_message(f"{YELLOW}Driver {driver_name} é um driver novo. Copiando para a EFI...{NC}")
                    try:
                        shutil.copy2(new_driver_path, efi_driver_path)
                    except Exception as e:
                        log_message(f"{RED}Erro ao copiar {driver_name}: {e}{NC}")
                        exit(1)
            else:
                log_message(f"{YELLOW}Driver {driver_name} não está habilitado no config.plist. Pulando.{NC}")

    log_message(f"{GREEN}Drivers atualizados com sucesso.{NC}")

def is_generic_placeholder_key(key):
    """Checks if a key is a generic placeholder that should be ignored (except 'Unload')."""
    return key.upper() in ("GENERIC")

def is_generic_comment_or_placeholder(item):
    """Checks if an item is a generic comment or placeholder that should be ignored."""
    comment = item.get('Comment', '').upper()
    path = item.get('Path', '').upper()
    bundle_path = item.get('BundlePath', '').upper()
    # Lista de placeholders comuns
    common_placeholders = ["MY CUSTOM", "READ THE COMMENT", "INTEL ETHERNET", "XHC PORTS", "APPLEMCEREPORTER", "MEMORY TESTING"]
    return any(phrase in comment for phrase in common_placeholders) or comment == '' or 'SAMPLE' in comment or 'GENERIC' in path or 'GENERIC' in bundle_path

def is_warning_key(key):
    """Checks if a key is a warning comment."""
    return key.upper().startswith("#WARNING")

def add_new_keys_to_config(config_plist_path, source_opencore_dir):
    """Adiciona novas chaves do Sample.plist ao config.plist."""
    log_message(
        f"{YELLOW}Adicionando novas chaves do Sample.plist ao config.plist...{NC}"
    )
    sample_config = os.path.join(source_opencore_dir, "Docs", "Sample.plist")

    if not os.path.isfile(sample_config) or not os.path.isfile(config_plist_path):
        log_message(f"{RED}Erro: Arquivos de configuração não encontrados.{NC}")
        exit(1)

    try:
        with open(config_plist_path, "rb") as f:
            current_plist = plistlib.load(f)
        with open(sample_config, "rb") as f:
            sample_plist = plistlib.load(f)
    except Exception as e:
        log_message(f"{RED}Erro ao ler os arquivos plist: {e}{NC}")
        exit(1)

    def add_new_keys_recursive(current_dict, sample_dict):
        """Recursively adds new keys from sample_dict to current_dict."""
        for key, value in sample_dict.items():
            if key not in current_dict:
                # Adiciona a chave somente se não for um warning, placeholder genérico ou a chave específica PciRoot(0x0)/Pci(0x1b,0x0)
                if not is_warning_key(key) and not is_generic_placeholder_key(key) and key != "PciRoot(0x0)/Pci(0x1b,0x0)":
                    log_message(f"Adicionando nova chave: {key}")
                    current_dict[key] = value
                elif key.upper() == "UNLOAD":  # Unload ainda é uma exceção e deve ser adicionada
                    log_message(f"Adicionando nova chave: {key}")
                    current_dict[key] = value
            else:
                if isinstance(value, dict) and isinstance(current_dict[key], dict):
                    add_new_keys_recursive(current_dict[key], value)
                elif isinstance(value, list) and isinstance(current_dict[key], list):
                    current_dict[key] = add_new_items_to_list(current_dict[key], value, key)

    def add_new_items_to_list(current_list, sample_list, parent_key=None):
        """Adds new items from sample_list to current_list, handling dictionaries more intelligently."""
        new_list = current_list[:]

        for sample_item in sample_list:
            if isinstance(sample_item, dict):
                found_similar = False
                for current_item in new_list:
                    if isinstance(current_item, dict):
                        # Consider items similar if they have the same 'Path' for UEFI drivers
                        if 'Path' in sample_item and 'Path' in current_item and sample_item['Path'] == current_item['Path']:
                            found_similar = True
                            break
                        # Consider items similar if they have the same 'BundlePath' for Kernel -> Add
                        if 'BundlePath' in sample_item and 'BundlePath' in current_item and sample_item['BundlePath'] == current_item['BundlePath']:
                            found_similar = True
                            break
                        # Consider items similar if they have the same 'Identifier' for Kernel -> Add
                        if 'Identifier' in sample_item and 'Identifier' in current_item and sample_item['Identifier'] == current_item['Identifier']:
                            found_similar = True
                            break
                        # Consider items similar if they have the same 'Comment' for ACPI -> Patch, Kernel -> Patch
                        if 'Comment' in sample_item and 'Comment' in current_item and sample_item['Comment'] == current_item['Comment']:
                            found_similar = True
                            break
                        # Special handling for 'Generic' inside 'PlatformInfo'
                        if parent_key == "PlatformInfo" and "Generic" in current_item and "Generic" in sample_item:
                            found_similar = True
                            break

                if not found_similar:
                    # Adiciona o item somente se ele não for um comentário genérico ou um placeholder
                    if not is_generic_comment_or_placeholder(sample_item):
                        log_message(f"Adicionando novo item à lista: {sample_item.get('Comment', sample_item.get('Path', sample_item.get('BundlePath', 'Generic')))}")
                        new_list.append(sample_item)
            else:
                # Adiciona itens simples (não dicionários) somente se não existirem na lista atual
                if sample_item not in new_list:
                    log_message(f"Adicionando novo item à lista: {sample_item}")
                    new_list.append(sample_item)

        return new_list

    log_message(f"{YELLOW}Executando add_new_keys para adicionar novas chaves...{NC}")
    add_new_keys_recursive(current_plist, sample_plist)

    try:
        with open(config_plist_path, "wb") as f:
            plistlib.dump(current_plist, f)
        log_message(f"{GREEN}Novas chaves adicionadas com sucesso ao config.plist!{NC}")
    except Exception as e:
        log_message(f"{RED}Erro ao salvar o config.plist atualizado: {e}{NC}")
        exit(1)

# Modificação na função validate_config_plist para usar o caminho do ocvalidate
def validate_config_plist(config_plist_path, ocvalidate_path):
    """Valida o config.plist usando ocvalidate, se disponível."""
    if ocvalidate_path is None:
        log_message(f"{YELLOW}Aviso: ocvalidate não encontrado. A validação do config.plist será pulada.{NC}")
        return

    log_message(f"{YELLOW}Validando o config.plist com ocvalidate...{NC}")
    try:
        result = subprocess.run(
            [
                ocvalidate_path,
                config_plist_path,
            ],
            capture_output=True,
            text=True,
            check=False,  # Não encerrar se houver erros de validação
        )
        # Saída separada por cor:
        if result.returncode == 0:
            log_message(f"{GREEN}ocvalidate: {config_plist_path} é válido.{NC}")
        else:
            log_message(f"{RED}ocvalidate encontrou problemas em {config_plist_path}:{NC}")
            log_message(result.stdout)

            # Perguntar ao usuário se ele quer continuar mesmo com erros de validação
            while True:
                choice = input(f"{YELLOW}Continuar mesmo assim? (s/n): {NC}").lower()
                if choice in ["s", "sim"]:
                    break
                elif choice in ["n", "não"]:
                    log_message(f"{RED}Operação abortada pelo usuário.{NC}")
                    exit(1)
                else:
                    log_message(f"{RED}Opção inválida. Responda com 's' ou 'n'.{NC}")

    except Exception as e:
        log_message(f"{RED}Erro ao executar ocvalidate: {e}{NC}")

def cleanup(temp_dir):
    """Limpa arquivos temporários."""
    log_message(f"{YELLOW}Limpando arquivos temporários...{NC}")
    try:
        if temp_dir and os.path.exists(temp_dir):  # Verifica se temp_dir existe # Modificação
            shutil.rmtree(temp_dir)
            log_message(f"{GREEN}Diretório temporário {temp_dir} removido.{NC}")
    except Exception as e:
        log_message(f"{RED}Erro ao limpar arquivos temporários: {e}{NC}")

def main():
    """Função principal."""
    global temp_dir_main  # Torna a variável global
    temp_dir_main = None  # Inicializa a variável
    check_environment()
    check_dependencies()

    efi_dir = list_all_efi()
    config_plist_path = find_config_plist(efi_dir)

    if config_plist_path is None:
        exit(1)

    current_version = get_efi_oc_version(config_plist_path)
    latest_version = get_latest_oc_version()

    if current_version and latest_version:
        update_available = compare_oc_versions(current_version, latest_version)
    else:
        update_available = False  # Não podemos determinar, então assumimos que não há atualização

    # temp_dir_main = None #  removida essa inicialização
    try:
        while True:
            print(f"{YELLOW}----- Menu Principal -----{NC}")
            print(f"Partição EFI selecionada: {efi_dir}")
            print(f"Versão atual do OpenCore (detectada): {current_version if current_version else 'Não detectada'}")
            print(f"Versão mais recente do OpenCore: {latest_version if latest_version else 'Não disponível'}")
            if update_available:
                print(f"{GREEN}Nova versão do OpenCore disponível!{NC}")
            print("Escolha uma opção:")
            print("1. Atualizar o OpenCore (RELEASE)")
            print("2. Atualizar o OpenCore (DEBUG)")
            print("3. Atualizar apenas drivers")
            print("4. Adicionar novas chaves ao config.plist")
            print("5. Sair")

            choice = input("Opção: ")

            if choice == "1":
                temp_dir_main, source_opencore_dir = download_oc("RELEASE")
                ocvalidate_path = check_ocvalidate(source_opencore_dir)
                backup_efi(efi_dir)
                update_efi(efi_dir, source_opencore_dir, "RELEASE")
                # Check EFI permissions before looking for config.plist
                check_efi_permissions(efi_dir)
                update_drivers(efi_dir, config_plist_path, source_opencore_dir)
                add_new_keys_to_config(config_plist_path, source_opencore_dir)
                validate_config_plist(config_plist_path, ocvalidate_path)
                log_message(f"{GREEN}Atualização do OpenCore concluída com sucesso!{NC}")
                break
            elif choice == "2":
                temp_dir_main, source_opencore_dir = download_oc("DEBUG")
                ocvalidate_path = check_ocvalidate(source_opencore_dir)
                backup_efi(efi_dir)
                update_efi(efi_dir, source_opencore_dir, "DEBUG")
                # Check EFI permissions before looking for config.plist
                check_efi_permissions(efi_dir)
                update_drivers(efi_dir, config_plist_path, source_opencore_dir)
                add_new_keys_to_config(config_plist_path, source_opencore_dir)
                validate_config_plist(config_plist_path, ocvalidate_path)
                log_message(f"{GREEN}Atualização do OpenCore concluída com sucesso!{NC}")
                break
            elif choice == "3":
                temp_dir_main, source_opencore_dir = download_oc("RELEASE")
                # Check EFI permissions before looking for config.plist
                check_efi_permissions(efi_dir)
                update_drivers(efi_dir, config_plist_path, source_opencore_dir)
                log_message(f"{GREEN}Drivers atualizados com sucesso!{NC}")
                break
            elif choice == "4":
                temp_dir_main, source_opencore_dir = download_oc("RELEASE")
                # Check EFI permissions before looking for config.plist
                check_efi_permissions(efi_dir)
                add_new_keys_to_config(config_plist_path, source_opencore_dir)
                validate_config_plist(config_plist_path, ocvalidate_path)
                log_message(f"{GREEN}Novas chaves adicionadas com sucesso!{NC}")
                break
            elif choice == "5":
                log_message(f"{YELLOW}Saindo do script...{NC}")
                exit()
            else:
                log_message(f"{RED}Opção inválida. Por favor, escolha uma opção válida.{NC}")
        
            pass
    except Exception as e:
            log_message(f"{RED}Erro durante a execução do script: {e}{NC}")
    finally:
            if 'temp_dir_main' in globals() and temp_dir_main and os.path.exists(temp_dir_main): # Verifica se temp_dir_main foi definido e se existe
                cleanup(temp_dir_main)

if __name__ == "__main__":
    try:
        main()
    finally:
        if 'temp_dir_main' in globals() and temp_dir_main and os.path.exists(temp_dir_main): # Verifica se temp_dir_main foi definido e se existe
            cleanup(temp_dir_main)