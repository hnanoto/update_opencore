import os
import sys
import subprocess
import requests
import plistlib
import shutil
from datetime import datetime

# Cores para feedback visual
RED = "\033[0;31m"
GREEN = "\033[0;32m"
YELLOW = "\033[0;33m"
NC = "\033[0;m"  # Sem cor

# Caminho absoluto para o diretório do script
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))

# Arquivo de log
LOGFILE = f"update_opencore_{datetime.now().strftime('%Y%m%d%H%M%S')}.log"

def log(message):
    """Registra a mensagem no arquivo de log e a imprime na tela."""
    with open(LOGFILE, "a") as logfile:
        logfile.write(message + "\n")
    print(message)

def download_hfs_driver():
    """Baixa o HFSPlus.efi do repositório OcBinaryData."""
    log(f"{YELLOW}Baixando HFSPlus.efi do repositório OcBinaryData...{NC}")
    # Link correto para o HFSPlus.efi (2024-01-09)
    hfs_driver_url = "https://github.com/acidanthera/OcBinaryData/blob/master/Drivers/HfsPlus.efi"

    log(f"Link de download do HFSPlus.efi encontrado: {hfs_driver_url}")
    try:
        response = requests.get(hfs_driver_url, stream=True)
        response.raise_for_status()  # Verifica se houve erro na requisição
        with open(os.path.join(SCRIPT_DIR, "HfsPlus.efi"), "wb") as f:
            for chunk in response.iter_content(chunk_size=8192):
                f.write(chunk)
    except requests.exceptions.RequestException as e:
        log(f"{RED}Erro: O download do HFSPlus.efi falhou: {e}{NC}")
        sys.exit(1)

    if not os.path.isfile(os.path.join(SCRIPT_DIR, "HfsPlus.efi")):
        log(f"{RED}Erro: O download do HFSPlus.efi falhou.{NC}")
        sys.exit(1)

    log(f"{GREEN}HFSPlus.efi baixado com sucesso.{NC}")

def check_environment():
    """Verifica o ambiente e permissões."""
    log(f"{YELLOW}Verificando ambiente...{NC}")
    if not sys.platform.startswith("darwin"):
        log(f"{RED}Erro: Este script deve ser executado no macOS.{NC}")
        sys.exit(1)
    if os.geteuid() != 0:
        log(f"{YELLOW}Este script requer permissões de administrador. Solicitando sudo...{NC}")
        os.execvp("sudo", ["sudo"] + sys.argv)
    log(f"{GREEN}Ambiente verificado com sucesso.{NC}")

def check_dependencies():
    """Verifica as dependências."""
    log(f"{YELLOW}Verificando dependências...{NC}")
    dependencies = ["curl", "unzip", "python3"]
    for cmd in dependencies:
        if not shutil.which(cmd):
            log(f"{RED}Erro: Dependência '{cmd}' não encontrada.{NC}")
            if cmd == "python3":
                log(f"{YELLOW}O Python 3 é necessário para o script. Instale-o através do Homebrew com 'brew install python3'.{NC}")
            sys.exit(1)
    log(f"{GREEN}Todas as dependências estão disponíveis.{NC}")

def download_oc(build_type="RELEASE"):
    """Baixa e extrai a versão Release ou Debug do OpenCore."""
    log(f"{YELLOW}Baixando OpenCore versão {build_type}...{NC}")
    try:
        response = requests.get("https://api.github.com/repos/acidanthera/OpenCorePkg/releases/latest")
        response.raise_for_status()
        
        oc_url = None
        for asset in response.json()["assets"]:
            if f"-{build_type}.zip" in asset["browser_download_url"]:
                oc_url = asset["browser_download_url"]
                break

        if not oc_url:
            log(f"{RED}Erro: Não foi possível obter o link da versão {build_type} do OpenCore.{NC}")
            sys.exit(1)

        log(f"Link de download do OpenCore versão {build_type} encontrado: {oc_url}")
        response = requests.get(oc_url, stream=True)
        response.raise_for_status()
        with open("OpenCore.zip", "wb") as f:
            for chunk in response.iter_content(chunk_size=8192):
                f.write(chunk)
    except requests.exceptions.RequestException as e:
        log(f"{RED}Erro: Não foi possível acessar a API do GitHub ou baixar o OpenCore: {e}{NC}")
        sys.exit(1)

    if not os.path.isfile("OpenCore.zip"):
        log(f"{RED}Erro: O download do OpenCore falhou.{NC}")
        sys.exit(1)

    # Verificar se o arquivo ZIP é válido antes de tentar descompactá-lo
    try:
        subprocess.run(["unzip", "-tq", "OpenCore.zip"], check=True)
    except subprocess.CalledProcessError:
        log(f"{RED}Erro: O arquivo ZIP do OpenCore está corrompido ou inválido.{NC}")
        sys.exit(1)

    try:
        subprocess.run(["unzip", "-o", "OpenCore.zip", "-d", "OpenCore"], check=True)
    except subprocess.CalledProcessError:
        log(f"{RED}Erro: Falha ao extrair OpenCore.zip.{NC}")
        sys.exit(1)
    log(f"{GREEN}OpenCore versão {build_type} baixado e extraído com sucesso.{NC}")

def get_installed_opencore_version():
    """Detecta a versão do OpenCore instalada na EFI."""
    opencore_efi_path = os.path.join(EFI_DIR, "EFI", "OC", "OpenCore.efi")
    if os.path.exists(opencore_efi_path):
        try:
            # Executa o comando strings para buscar a versão do OpenCore.efi
            result = subprocess.run(
                ["strings", opencore_efi_path],
                capture_output=True,
                text=True,
                check=True
            )
            # Busca pela linha que contém a versão
            for line in result.stdout.splitlines():
                if "OpenCore.efi" in line:
                    version = line.split()[-2]
                    return version
        except subprocess.CalledProcessError as e:
            log(f"{RED}Erro ao detectar a versão do OpenCore: {e}{NC}")
    return "Não detectada"

def get_latest_opencore_version():
    """Obtém a versão mais recente do OpenCore da API do GitHub."""
    try:
        response = requests.get("https://api.github.com/repos/acidanthera/OpenCorePkg/releases/latest")
        response.raise_for_status()
        return response.json()["tag_name"]
    except requests.exceptions.RequestException as e:
        log(f"{RED}Erro: Não foi possível obter a versão mais recente do OpenCore: {e}{NC}")
        return "Desconhecida"

def list_all_efi():
    """Lista todas as partições EFI."""
    global EFI_DIR
    log(f"{YELLOW}Localizando todas as partições EFI no sistema...{NC}")
    try:
        diskutil_output = subprocess.check_output(["diskutil", "list"]).decode("utf-8")
        all_efis = [line.split()[-1] for line in diskutil_output.splitlines() if "EFI" in line]
    except subprocess.CalledProcessError:
        log(f"{RED}Erro: Falha ao executar 'diskutil list'.{NC}")
        sys.exit(1)

    if not all_efis:
        log(f"{RED}Erro: Nenhuma partição EFI encontrada.{NC}")
        sys.exit(1)

    log("Partições EFI detectadas:")
    for i, efi_part in enumerate(all_efis):
        log(f"{i + 1}. {efi_part}")

    while True:
        try:
            efi_choice = int(input(f"Selecione o número da partição EFI que deseja usar: ")) - 1
            if 0 <= efi_choice < len(all_efis):
                efi_part = all_efis[efi_choice]
                break
            else:
                log(f"{RED}Seleção inválida. Tente novamente.{NC}")
        except ValueError:
            log(f"{RED}Entrada inválida. Digite um número.{NC}")

    try:
        diskutil_info = subprocess.check_output(["diskutil", "info", efi_part]).decode("utf-8")
        efi_dir_line = [line.strip() for line in diskutil_info.splitlines() if "Mount Point" in line]
        if efi_dir_line:
            efi_dir = efi_dir_line[0].split(":")[-1].strip()
        else:
            efi_dir = ""
    except subprocess.CalledProcessError:
        log(f"{RED}Erro: Falha ao executar 'diskutil info {efi_part}'.{NC}")
        sys.exit(1)

    if not efi_dir:
        log(f"{RED}Erro: A partição EFI selecionada não está montada.{NC}")
        log(f"{YELLOW}Monte a EFI manualmente e execute o script novamente.{NC}")
        sys.exit(1)

    EFI_DIR = efi_dir
    log(f"Partição EFI selecionada: {EFI_DIR}")

def backup_efi():
    """Cria backup da EFI."""
    backup_dir = os.path.join(EFI_DIR, f"EFI-Backup-{datetime.now().strftime('%Y%m%d%H%M%S')}")
    log(f"{YELLOW}Criando backup em {backup_dir}...{NC}")
    try:
        shutil.copytree(os.path.join(EFI_DIR, "EFI"), backup_dir)
    except Exception as e:
        log(f"{RED}Erro ao criar o backup: {e}{NC}")
        sys.exit(1)
    log(f"{GREEN}Backup criado com sucesso.{NC}")

def update_efi(build_type="RELEASE"):
    """Atualiza os arquivos EFI, mas não a pasta Drivers."""
    efi_source_dir = os.path.join("OpenCore", "X64", "EFI")
    efi_target_dir = os.path.join(EFI_DIR, "EFI")

    if not os.path.isdir(efi_source_dir):
        log(f"{RED}Erro: Pasta EFI de origem não encontrada em {efi_source_dir}.{NC}")
        sys.exit(1)

    log(f"{YELLOW}Atualizando arquivos EFI em {efi_target_dir}...{NC}")
    try:
        # Copia todos os arquivos e pastas, exceto a pasta Drivers
        for item in os.listdir(efi_source_dir):
            source_item = os.path.join(efi_source_dir, item)
            target_item = os.path.join(efi_target_dir, item)

            if item == "Drivers":
                log(f"{YELLOW}Pulando a pasta Drivers conforme instruído.{NC}")
                continue

            if os.path.isdir(source_item):
                shutil.copytree(source_item, target_item, dirs_exist_ok=True)
            else:
                shutil.copy2(source_item, target_item)
        log(f"{GREEN}Arquivos EFI atualizados com sucesso, exceto a pasta Drivers.{NC}")
    except Exception as e:
        log(f"{RED}Erro ao atualizar arquivos EFI: {e}{NC}")
        sys.exit(1)

def get_enabled_drivers():
    """Obtém a lista de drivers habilitados no config.plist usando plistlib."""
    config_plist = os.path.join(EFI_DIR, "EFI", "OC", "config.plist")

    if not os.path.isfile(config_plist):
        log(f"{RED}Erro: Arquivo config.plist não encontrado em {config_plist}.{NC}")
        sys.exit(1)

    # Carrega o config.plist usando plistlib
    try:
        with open(config_plist, "rb") as f:
            plist_data = plistlib.load(f)
        log(f"{YELLOW}Arquivo config.plist carregado com sucesso usando plistlib.{NC}")
    except Exception as e:
        log(f"{RED}Erro ao carregar config.plist com plistlib: {e}{NC}")
        sys.exit(1)

    # Extrai os drivers habilitados da seção UEFI -> Drivers
    enabled_drivers = []
    try:
        drivers_array = plist_data["UEFI"]["Drivers"]
        log(f"{YELLOW}Lista de drivers (plistlib): {drivers_array}{NC}")

        for item in drivers_array:
            if isinstance(item, str):
                # Se o item é uma string, use a string diretamente como nome do driver.
                driver_name = item
            elif isinstance(item, dict) and item.get("Enabled", False):
                # Se o item é um dicionário, use a chave "Path" como nome do driver.
                driver_name = item.get("Path", "")
            else:
                continue  # Pula itens que não são nem string nem dicionário com "Enabled"

            # Remove a extensão .efi do nome do driver, se presente.
            if driver_name.endswith(".efi"):
                driver_name = driver_name[:-4]

            enabled_drivers.append(driver_name)

    except KeyError as e:
        log(f"{RED}Erro ao acessar a chave UEFI -> Drivers no config.plist: {e}{NC}")
    except Exception as e:
        log(f"{RED}Erro ao extrair drivers do config.plist com plistlib: {e}{NC}")

    log(f"{YELLOW}Drivers habilitados (plistlib): {enabled_drivers}{NC}")
    return enabled_drivers

def update_drivers():
    """Atualiza os drivers na pasta EFI/OC/Drivers e remove os não utilizados."""
    efi_drivers_dir = os.path.join(EFI_DIR, "EFI", "OC", "Drivers")
    new_drivers_dir = os.path.join("OpenCore", "X64", "EFI", "OC", "Drivers")

    if not os.path.isdir(efi_drivers_dir):
        log(f"{RED}Erro: Pasta de drivers EFI não encontrada em {efi_drivers_dir}.{NC}")
        sys.exit(1)

    enabled_drivers = get_enabled_drivers()
    
    # Adiciona a extensão .efi aos drivers habilitados
    enabled_drivers_with_extension = [
        driver + ".efi" if not driver.endswith(".efi") else driver
        for driver in enabled_drivers
    ]

    log(f"{YELLOW}Atualizando drivers em {efi_drivers_dir}...{NC}")

    # Dicionário para rastrear quais drivers foram processados ou existem na EFI
    processed_drivers = {}

    # Marca todos os drivers habilitados como processados
    for driver in enabled_drivers_with_extension:
        processed_drivers[driver] = True

    # Verifica e baixa o HfsPlus.efi se necessário
    hfsplus_driver = "HfsPlus.efi"
    if hfsplus_driver in enabled_drivers_with_extension and not os.path.exists(os.path.join(efi_drivers_dir, hfsplus_driver)):
        log(f"{YELLOW}Baixando {hfsplus_driver} do repositório OcBinaryData...{NC}")
        download_hfs_driver()
        
        # Verifica se o HfsPlus.efi foi baixado com sucesso antes de tentar copiá-lo
        if os.path.exists(os.path.join(SCRIPT_DIR, hfsplus_driver)):
            try:
                shutil.copy2(os.path.join(SCRIPT_DIR, hfsplus_driver), os.path.join(efi_drivers_dir, hfsplus_driver))
                log(f"{GREEN}{hfsplus_driver} copiado para a pasta Drivers da EFI.{NC}")
            except Exception as e:
                log(f"{RED}Erro ao copiar {hfsplus_driver} para a pasta Drivers da EFI: {e}{NC}")
                sys.exit(1)
        else:
            log(f"{RED}Erro: {hfsplus_driver} não foi baixado com sucesso.{NC}")
            sys.exit(1)

    # Atualiza os drivers habilitados
    for new_driver in os.listdir(new_drivers_dir):
        if not new_driver.endswith(".efi"):
            continue

        new_driver_path = os.path.join(new_drivers_dir, new_driver)
        efi_driver_path = os.path.join(efi_drivers_dir, new_driver)

        if new_driver in enabled_drivers_with_extension:
            log(f"{YELLOW}Atualizando {new_driver} (sobrescrevendo)...{NC}")
            try:
                shutil.copy2(new_driver_path, efi_driver_path)
            except Exception as e:
                log(f"{RED}Erro ao atualizar {new_driver}: {e}{NC}")
                sys.exit(1)
        else:
            log(f"{YELLOW}Driver {new_driver} não está habilitado no config.plist. Pulando.{NC}")

    # Remove drivers não utilizados
    log(f"{YELLOW}Removendo drivers não utilizados da pasta {efi_drivers_dir}...{NC}")
    for efi_driver in os.listdir(efi_drivers_dir):
        if efi_driver.endswith(".efi") and efi_driver not in processed_drivers:
            efi_driver_path = os.path.join(efi_drivers_dir, efi_driver)
            log(f"{YELLOW}Removendo driver não utilizado: {efi_driver}{NC}")
            try:
                os.remove(efi_driver_path)
            except Exception as e:
                log(f"{RED}Erro ao remover {efi_driver}: {e}{NC}")
                sys.exit(1)

    log(f"{GREEN}Drivers atualizados e drivers não utilizados removidos com sucesso.{NC}")

def create_python_script():
    """Cria o script Python add_new_keys.py."""
    script_content = """
#!/usr/bin/env python3
import plistlib
import sys

def add_new_keys(current_plist_path, sample_plist_path):
    \"\"\"
    Adds new keys from the sample plist to the current plist,
    without modifying existing keys.

    Args:
        current_plist_path: Path to the current config.plist.
        sample_plist_path: Path to the Sample.plist.
    \"\"\"

    try:
        with open(current_plist_path, "rb") as f:
            current_plist = plistlib.load(f)
        with open(sample_plist_path, "rb") as f:
            sample_plist = plistlib.load(f)
    except Exception as e:
        print(f"Erro ao ler os arquivos plist: {e}")
        sys.exit(1)

    def add_new_keys_recursive(current_dict, sample_dict):
        \"\"\"Recursively adds new keys from sample_dict to current_dict.\"\"\"
        for key, value in sample_dict.items():
            if key not in current_dict:
                # Adiciona a chave somente se não for um warning, placeholder genérico ou a chave específica PciRoot(0x0)/Pci(0x1b,0x0)
                if not is_warning_key(key) and not is_generic_placeholder_key(key) and key != "PciRoot(0x0)/Pci(0x1b,0x0)":
                    print(f"Adicionando nova chave: {key}")
                    current_dict[key] = value
                elif key.upper() == "UNLOAD":  # Unload ainda é uma exceção e deve ser adicionada
                    print(f"Adicionando nova chave: {key}")
                    current_dict[key] = value
            else:
                if isinstance(value, dict) and isinstance(current_dict[key], dict):
                    add_new_keys_recursive(current_dict[key], value)
                elif isinstance(value, list) and isinstance(current_dict[key], list):
                    current_dict[key] = add_new_items_to_list(current_dict[key], value, key)

    def add_new_items_to_list(current_list, sample_list, parent_key=None):
        \"\"\"Adds new items from sample_list to current_list, handling dictionaries more intelligently.\"\"\"
        new_list = current_list[:]

        for sample_item in sample_list:
            if isinstance(sample_item, dict):
                found_similar = False
                for current_item in new_list:
                    if isinstance(current_item, dict):
                        # Consider items similar if they have the same 'Path' for UEFI drivers
                        if 'Path' in sample_item and 'Path' in current_item and sample_item['Path'] == current_item['Path']:
                            found_similar = True
                            break
                        # Consider items similar if they have the same 'BundlePath' for Kernel -> Add
                        if 'BundlePath' in sample_item and 'BundlePath' in current_item and sample_item['BundlePath'] == current_item['BundlePath']:
                            found_similar = True
                            break
                        # Consider items similar if they have the same 'Identifier' for Kernel -> Add
                        if 'Identifier' in sample_item and 'Identifier' in current_item and sample_item['Identifier'] == current_item['Identifier']:
                            found_similar = True
                            break
                        # Consider items similar if they have the same 'Comment' for ACPI -> Patch, Kernel -> Patch
                        if 'Comment' in sample_item and 'Comment' in current_item and sample_item['Comment'] == current_item['Comment']:
                            found_similar = True
                            break
                        # Special handling for 'Generic' inside 'PlatformInfo'
                        if parent_key == "PlatformInfo" and "Generic" in current_item and "Generic" in sample_item:
                            found_similar = True
                            break

                if not found_similar:
                    # Adiciona o item somente se ele não for um comentário genérico ou um placeholder
                    if not is_generic_comment_or_placeholder(sample_item):
                        print(f"Adicionando novo item à lista: {sample_item.get('Comment', sample_item.get('Path', sample_item.get('BundlePath', 'Generic')))}")
                        new_list.append(sample_item)
            else:
                # Adiciona itens simples (não dicionários) somente se não existirem na lista atual
                if sample_item not in new_list:
                    print(f"Adicionando novo item à lista: {sample_item}")
                    new_list.append(sample_item)

        return new_list

    def is_generic_placeholder_key(key):
        \"\"\"Checks if a key is a generic placeholder that should be ignored (except 'Unload').\"\"\"
        return key.upper() in ("GENERIC")

    def is_generic_comment_or_placeholder(item):
        \"\"\"Checks if an item is a generic comment or placeholder that should be ignored.\"\"\"
        comment = item.get('Comment', '').upper()
        path = item.get('Path', '').upper()
        bundle_path = item.get('BundlePath', '').upper()
        # Lista de placeholders comuns
        common_placeholders = ["MY CUSTOM", "READ THE COMMENT", "INTEL ETHERNET", "XHC PORTS", "APPLEMCEREPORTER", "MEMORY TESTING"]
        return any(phrase in comment for phrase in common_placeholders) or comment == '' or 'SAMPLE' in comment or 'GENERIC' in path or 'GENERIC' in bundle_path

    def is_warning_key(key):
        \"\"\"Checks if a key is a warning comment.\"\"\"
        return key.upper().startswith("#WARNING")

    add_new_keys_recursive(current_plist, sample_plist)

    try:
        with open(current_plist_path, "wb") as f:
            plistlib.dump(current_plist, f)
    except Exception as e:
        print(f"Erro ao salvar o config.plist atualizado: {e}")
        sys.exit(1)

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Uso: python3 add_new_keys.py <current_config.plist> <Sample.plist>")
        sys.exit(1)

    current_plist_path = sys.argv[1]
    sample_plist_path = sys.argv[2]

    add_new_keys(current_plist_path, sample_plist_path)
"""
    with open(os.path.join(SCRIPT_DIR, "add_new_keys.py"), "w") as f:
        f.write(script_content)

def add_new_keys_to_config():
    """Adiciona novas chaves do Sample.plist ao config.plist."""
    log(f"{YELLOW}Adicionando novas chaves do Sample.plist ao config.plist...{NC}")
    sample_config = os.path.join("OpenCore", "Docs", "Sample.plist")
    current_config = os.path.join(EFI_DIR, "EFI", "OC", "config.plist")

    if not os.path.isfile(sample_config) or not os.path.isfile(current_config):
        log(f"{RED}Erro: Arquivos de configuração não encontrados.{NC}")
        sys.exit(1)

    # Chama o script Python para adicionar novas chaves, preservando as existentes
    log(f"{YELLOW}Executando add_new_keys.py para adicionar novas chaves...{NC}")
    try:
        subprocess.run(["python3", os.path.join(SCRIPT_DIR, "add_new_keys.py"), current_config, sample_config], check=True)
    except subprocess.CalledProcessError:
        log(f"{RED}Erro ao adicionar novas chaves ao config.plist.{NC}")
        sys.exit(1)

    log(f"{GREEN}Novas chaves adicionadas com sucesso ao config.plist!{NC}")

def validate_config_plist():
    """Valida o config.plist usando ocvalidate."""
    ocvalidate_path = os.path.join("OpenCore", "Utilities", "ocvalidate", "ocvalidate")
    config_plist_path = os.path.join(EFI_DIR, "EFI", "OC", "config.plist")

    if not os.path.isfile(ocvalidate_path):
        log(f"{RED}Erro: ocvalidate não encontrado em {ocvalidate_path}. Baixe a versão mais recente do OpenCore.{NC}")
        return

    if not os.path.isfile(config_plist_path):
        log(f"{RED}Erro: config.plist não encontrado em {config_plist_path}.{NC}")
        return

    log(f"{YELLOW}Validando config.plist com ocvalidate...{NC}")
    try:
        result = subprocess.run([ocvalidate_path, config_plist_path], capture_output=True, text=True, check=False)
        
        # Verifica se o comando foi executado com sucesso (código de saída 0)
        if result.returncode == 0:
            log(f"{GREEN}Validação do config.plist concluída com sucesso. Saída do ocvalidate:{NC}\n{result.stdout}")
        else:
            log(f"{RED}Erro na validação do config.plist. Saída do ocvalidate:{NC}\n{result.stdout}")

    except subprocess.CalledProcessError as e:
        log(f"{RED}Erro ao executar ocvalidate: {e.stderr}{NC}")

def cleanup():
    """Limpa arquivos temporários."""
    log(f"{YELLOW}Limpando arquivos temporários...{NC}")
    try:
        os.remove("OpenCore.zip")
    except FileNotFoundError:
        pass
    try:
        shutil.rmtree("OpenCore")
    except FileNotFoundError:
        pass
    try:
        os.remove(os.path.join(SCRIPT_DIR, "add_new_keys.py"))
    except FileNotFoundError:
        pass
    log(f"{GREEN}Limpeza concluída.{NC}")

# Registra a função de limpeza para ser executada na saída
import atexit
atexit.register(cleanup)

def main():
    """Função principal que exibe o menu e executa as ações."""
    check_environment()
    check_dependencies()
    list_all_efi()

    current_version = get_installed_opencore_version()
    latest_version = get_latest_opencore_version()

    log(f"Versão atual do OpenCore (detectada): {current_version}")
    log(f"Versão mais recente do OpenCore: {latest_version}")

    while True:
        print("\nEscolha uma opção:")
        print("1. Atualizar o OpenCore (RELEASE)")
        print("2. Atualizar o OpenCore (DEBUG)")
        print("3. Atualizar apenas drivers")
        print("4. Adicionar novas chaves ao config.plist")
        print("5. Validar config.plist")
        print("6. Sair")

        try:
            choice = int(input("Opção: "))
        except ValueError:
            log(f"{RED}Entrada inválida. Digite um número.{NC}")
            continue

        if choice == 1:
            backup_efi()
            download_oc("RELEASE")
            update_efi("RELEASE")
            update_drivers()
            create_python_script()
            cleanup()
            log(f"{GREEN}OpenCore (RELEASE) atualizado com sucesso!{NC}")
        elif choice == 2:
            backup_efi()
            download_oc("DEBUG")
            update_efi("DEBUG")
            update_drivers()
            create_python_script()
            cleanup()
            log(f"{GREEN}OpenCore (DEBUG) atualizado com sucesso!{NC}")
        elif choice == 3:
            backup_efi()
            download_oc("RELEASE")
            update_drivers()
            cleanup()
            log(f"{GREEN}Drivers atualizados com sucesso!{NC}")
        elif choice == 4:
            create_python_script()
            backup_efi()
            download_oc("RELEASE")
            add_new_keys_to_config()
            cleanup()
            log(f"{GREEN}Novas chaves adicionadas ao config.plist!{NC}")
        elif choice == 5:
            download_oc("RELEASE")
            validate_config_plist()
            cleanup()
        elif choice == 6:
            log(f"{YELLOW}Saindo...{NC}")
            sys.exit(0)
        else:
            log(f"{RED}Opção inválida. Tente novamente.{NC}")

if __name__ == "__main__":
    main()